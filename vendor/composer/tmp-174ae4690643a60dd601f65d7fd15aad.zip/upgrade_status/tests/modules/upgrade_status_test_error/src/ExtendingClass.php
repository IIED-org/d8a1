<?php

namespace Drupal\upgrade_status_test_error;

/**
 * A dummy class to test that extension of a deprecated class is detected.
 *
 * @group upgrade_status_test_error
 */
class ExtendingClass extends DeprecatedBaseClass {

}
