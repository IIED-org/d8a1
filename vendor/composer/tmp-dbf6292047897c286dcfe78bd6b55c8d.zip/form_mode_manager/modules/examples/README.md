Form Mode Manager Examples module
===============================

Allows to use form_mode implement on Drupal 8 on each ContentEntity.

Requirement
-----------
You must have "BARTIK" theme installed to install this module.

Modules:

* node
* form_mode_manager

Configuration
-------------

* Create an content to test differents cases.
    * Create Node Form Mode Example (`node/add/form_mode_manager_examples`)
