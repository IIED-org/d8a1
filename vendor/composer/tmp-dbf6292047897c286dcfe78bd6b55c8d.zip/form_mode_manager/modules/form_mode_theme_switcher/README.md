Form Mode Manager theme switcher module
=======================================

Allows to define theme applicable per form_mode using form mode manager.

Requirement
-----------
You must use Form Mode Manager module to define all you need onto
 routes parameters.

Modules:

* Field
* Field UI
* Form Mode Manager

Configuration
-------------

@TODO
