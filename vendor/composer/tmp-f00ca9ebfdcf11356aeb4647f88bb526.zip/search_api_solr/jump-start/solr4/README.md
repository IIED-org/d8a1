There's no official docker image for Solr 4.
But we can use Solr 5 which is able to run in Solr 4 compatibility mode.
