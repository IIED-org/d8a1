There's no official docker image for Solr 4.
But we can use https://hub.docker.com/r/kshaner/solr/
