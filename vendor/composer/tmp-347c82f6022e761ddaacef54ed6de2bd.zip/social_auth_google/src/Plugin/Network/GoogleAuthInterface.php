<?php

namespace Drupal\social_auth_google\Plugin\Network;

use Drupal\social_auth\Plugin\Network\NetworkInterface;

/**
 * Defines the Google Auth interface.
 */
interface GoogleAuthInterface extends NetworkInterface {}
