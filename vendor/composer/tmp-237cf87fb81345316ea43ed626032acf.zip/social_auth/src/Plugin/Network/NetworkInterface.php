<?php

namespace Drupal\social_auth\Plugin\Network;

use Drupal\social_api\Plugin\NetworkInterface as NetworkInterfaceBase;

/**
 * Defines an interface for Social Auth Network.
 */
interface NetworkInterface extends NetworkInterfaceBase {}
