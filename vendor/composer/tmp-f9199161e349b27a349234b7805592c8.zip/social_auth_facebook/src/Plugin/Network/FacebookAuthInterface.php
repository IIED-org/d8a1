<?php

namespace Drupal\social_auth_facebook\Plugin\Network;

use Drupal\social_auth\Plugin\Network\NetworkInterface;

/**
 * Defines the Facebook Auth interface.
 */
interface FacebookAuthInterface extends NetworkInterface {}
