<?php

namespace Drupal\rabbit_hole\Exception;

/**
 * Exception for invalid redirect response.
 */
class InvalidRedirectResponseException extends \Exception {
}
