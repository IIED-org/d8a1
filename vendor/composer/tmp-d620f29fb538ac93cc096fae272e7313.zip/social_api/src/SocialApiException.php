<?php

namespace Drupal\social_api;

/**
 * Defines an Exception class for Social API.
 */
class SocialApiException extends \Exception {}
