<?php

namespace Drupal\geocoder\Annotation;

/**
 * Defines a geocoder formatter plugin annotation object.
 *
 * @Annotation
 */
class GeocoderFormatter extends GeocoderPluginBase {

}
