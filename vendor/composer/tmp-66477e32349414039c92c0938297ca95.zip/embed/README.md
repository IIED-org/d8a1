# Embed Module

Provides an API for embedding and a UI for creating embed buttons.
