<?php

namespace Drupal\memcache;

/**
 * Memcache specific exception.
 */
class MemcacheException extends \RuntimeException {}
