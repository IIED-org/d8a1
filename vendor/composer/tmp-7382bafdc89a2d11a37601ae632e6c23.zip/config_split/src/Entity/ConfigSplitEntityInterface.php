<?php

namespace Drupal\config_split\Entity;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Provides an interface for defining Configuration Split setting entities.
 */
interface ConfigSplitEntityInterface extends ConfigEntityInterface {

}
