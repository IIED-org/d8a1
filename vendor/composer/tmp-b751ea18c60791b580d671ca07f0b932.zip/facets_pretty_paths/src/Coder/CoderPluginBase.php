<?php

namespace Drupal\facets_pretty_paths\Coder;

use Drupal\facets\Processor\ProcessorPluginBase;

/**
 * A base class for plugins that implements most of the boilerplate.
 */
abstract class CoderPluginBase extends ProcessorPluginBase implements CoderInterface {}
