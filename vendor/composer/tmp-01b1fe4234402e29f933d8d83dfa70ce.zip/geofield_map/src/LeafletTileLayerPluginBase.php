<?php

namespace Drupal\geofield_map;

use Drupal\Component\Plugin\PluginBase;

/**
 * Base class for Leaflet tile layers plugin plugins.
 */
abstract class LeafletTileLayerPluginBase extends PluginBase {

}
